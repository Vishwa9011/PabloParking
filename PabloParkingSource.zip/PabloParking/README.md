# ✅✅✅ PabloParking

PabloParking

# ✅ Vehicle Details (required)

-    vehicle owner
-    vehicle number
-    vehicle type

# ✅ types of vehicle

-    car , bike , bus , truck

# ✅ 5 storey building

# ✅ we have 5 plcae for each vehicle on each storey

#

# ✅ building name = "PabloParking"

# ✅ parking floors = parking floor

# ✅ vehicle lane = "vehicleName" Lane

# ✅ vehicle slot = slot

```
# -------------------- UI Designing----------------------------

## Logo on left side
## nav-links => Home , About ,  Services, Contact Us
```
